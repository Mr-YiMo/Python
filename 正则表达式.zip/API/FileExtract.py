import re
import os
def Fun_DataExtract(file,DestData):
    #将标签中所有的数据另存至字符串
    with open(file,mode='r',encoding='utf-8') as f:
        content = f.read()
        print(content)
    #使用正则表达式对另存的数据进行读取
    print('------------------------------------start-------------------------------')
    p = re.compile(r'<TextualEncodings DefinesMinMax="False" Name="(.*)"\s?|DisplayValue="(.*)"\s+LowerBound="(\d+)"') #提取包含0次或任意次TextualEncodings的一行数据后的任意字符串
    for one in p.findall(content,re.DOTALL):
        print(type(one),one)
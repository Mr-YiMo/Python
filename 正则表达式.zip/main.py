import os
import API.FileTransfer
import API.FileExtract
#文件路径
fileSourceRoad = r'C:\Users\zw192\Desktop\Python\正则表达式\SampleFile\0730测试_API详表l - 副本.vCODM'
#文件源格式
fileSrcFormat = '.vCODM'
#目标格式
fileDestFormat = '.xml'
#提取数据类型：FileExtractHelp.txt文档
fileDestData = 1

new_name = API.FileTransfer.Fun_FileRename(fileSourceRoad,fileSrcFormat,fileDestFormat)
print(new_name)
API.FileExtract.Fun_DataExtract(new_name,fileDestData)





import pytest
import time

import setuptools

#测试类
class TestLogin:

    def setup_class(self):
        print("\n给类做一些前置工作");

    #夹具
    def setup_method(self):
        print("\n给用例做一些前置工作");

    #测试用例/测试接口/测试函数
    @pytest.mark.run(order=2) #装饰器：第二个执行
    @pytest.mark.smoke #装饰器：自定义测试分组，比如冒烟测试
    def test_login_01_Print(self):
        time.sleep(3)
        print("这是一个TestLogin用例！")
        assert 1==2 #断言

    # @pytest.mark.skip(reason = '不想执行')
    @pytest.mark.run(order=1)  #装饰器：第一个执行
    @pytest.mark.useragemode
    def test_login_02_Print(self):
        time.sleep(3)
        print("这是一个TestLogin用例！")

    def teardown_method(self):
        print("\n给用例一些结束动作")

    def teardown_class(self):
        print("\n给类做一些结束工作");

import pytest
import requests


#测试类
class TestEcuSleepWakeup:
    #测试用例/测试接口/测试函数
    def test_01_sleep(self,test_fixture):
        print("这是一个测试ECU休眠用例！")

    @pytest.mark.useragemode #装饰器
    def test_02_wakeup(self,test_fixture,test_fixture2):
        print("这是一个测试ECU唤醒用例！")
        print(str(test_fixture));

    @pytest.mark.useragemode  # 装饰器
    @pytest.mark.parametrize('kind,name',[['animal1','dog'],['animal2','cat']])
    def test_03_parameter(self,kind,name):
        url = ''
        requests.get()
        print("数据驱动：{%s %s}" %(kind,name))


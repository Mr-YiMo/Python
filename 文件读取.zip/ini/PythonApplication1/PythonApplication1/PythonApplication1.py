# -*- coding: GB2312 -*-
import configparser
#ʵ��������
config = configparser.ConfigParser()
config['defaut'] = {"IP":"192.168.69.2","Port":15,"User":"zhang075","password":"12345678"}
config['VIU1'] = {"IP":"192.168.69.3","Port":15,"User":"zhang075","password":"12345678"}

'''д��'''
with open("./config.ini",mode="w",encoding="utf8") as file:
       config.write(file)

'''��ȡ'''
config.read("./config.ini")
print(config.sections())

for section in config.sections():
    print(section,config[section])
    for key in config[section]:
        print(key,config[section].get(key))


import pytest

#测试类
class TestcaseInterface:
    #测试用例/测试接口/测试函数
    @pytest.mark.smoke  # 自定义测试分组，比如冒烟测试
    def test_01_Print(self):
        print("这是一个Interface接口！")

#测试接口
def test_02_TestcaseInterface():
    print("这是一个Interface函数！")
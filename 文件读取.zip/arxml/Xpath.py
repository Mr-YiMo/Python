import xml.etree.ElementTree as ET
import re
import os
import time
import Elements_PersonalFuntion
import DataType



#创建一个解析副本，保护源文件不被破坏
FileSourcePath  = r'.\Database\SDB22R01_SRS_220218_AR-4.2.2_UnFlattened_All_PreRelease.arxml'
copyfilePath = Elements_PersonalFuntion.FileRename(FileSourcePath,None)

message = DataType.CANMessage()
print(message.MessageID)

#正则删除命名空间xmlns，目前不考虑Fibex文件
pattern = r'xmlns.*"'
replacement = ''
with open(copyfilePath,'r') as file:
    text = file.read()

    matches = re.findall(pattern, text)
    for info in matches:
        print("Regularity : "+info)

    new_text = re.sub(pattern,replacement,text)
    file.close()

with open(copyfilePath,'w') as file:
    file.write(new_text)
    file.close()
del new_text,text

#ElementTree开始处理xml文件
print("CopyFilePath = "+copyfilePath)
tree = ET.parse(copyfilePath)
root = tree.getroot()
# for info in root.iter():
#     print(info)

# def writeXML(self, xmlpath='..\Database\Sample_SDB21R01_BackboneFR_211225_Release.xml'):
#     tree.write(xmlpath)

# tree = ET.parse('.\Database\SDB21R01_BackboneFR_211225_Release.xml')
# writeXML(tree)

# tree = ET.parse('.\Database\Sample_SDB21R01_BackboneFR_211225_Release.xml')
# root = tree.getroot()
# for info in root:
#     print(info)



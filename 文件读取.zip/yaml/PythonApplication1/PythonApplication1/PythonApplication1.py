import yaml
data = """
hosue:
    family:
        -cast
        -dog
        -goldfish
"""

#д���ȡ
with open("./data.yaml",mode="w",encoding="utf8") as file:
     print(yaml.safe_dump(data,file))#ת��Ϊyaml��ʽ������

with open("./data.yaml",mode="r",encoding="utf8") as file:
     print(yaml.safe_load(file))#����yaml�ļ�

list1 = [0,1,2,3]
list2 = [4,5,6,7]
i =0
while list1 or list2:
    if list1:
        print("list1")
    if list2:
       print("list2")
    if i == 2:
        break
    i+=1
from enum import Enum
class CanMessageType(Enum):
    CAN = 0
    CANFD = 1
    CANXL = 2

class CANMessage():
    def __init__(self,MsgID = 0x00,MsgName = '') -> None:
        self.MsgID = 0x00
        self.MsgName = ''
        self.MsgLen = 0
        self.MsgType = CanMessageType.CAN
        self.Senders = ''
        self.Receivers = ''
        self.PDUName = ''
        self.SigName = ''

class CANMessageArray():
    def __int__(self):
        self.message_map = {}#字典
    def add_message(self,MsgID = 0x00,MsgName = ''):
        frame = CANMessage(MsgID,MsgName)
        self.message_map[MsgID] = frame

    #仅支持通过MsgID查找Messgae对象
    def get_message(self,MsgID):
        return self.message_map[MsgID] #返回一个类对象用于后续的处理

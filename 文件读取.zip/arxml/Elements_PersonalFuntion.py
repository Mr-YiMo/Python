import os
import sys
import shutil
try:
    import xml.etree.cElementTree as ET
except ImportError:
    import xml.etree.ElementTree as ET

#save a copy file to protect source file.
def FileRename(fileSourcePath,fileDestFormat = None):
    extendName = os.path.splitext(fileSourcePath)
    print(extendName)

    if extendName[1] == None:
        print('Filename is None! Please check source file name.')
        sys.exit()

    try:
        if fileDestFormat == None:
            fileDestFormat = extendName[1]
        newname = extendName[0]+'_copy' + fileDestFormat
        shutil.copyfile(fileSourcePath, newname)
    except FileExistsError as err:
        print('请确认文件夹存在性！',err)
    except FileNotFoundError as err:
        print('请确认文件夹路径的正确性！',err)


    return newname
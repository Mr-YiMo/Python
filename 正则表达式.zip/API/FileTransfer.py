import os
import sys
import shutil

def Fun_FileRename(fileSourceRoad,fileSrcFormat,fileDestFormat):
    extendName = os.path.splitext(fileSourceRoad)
    print(extendName)

    if extendName[1] == fileSrcFormat:
        print('Extend name get success！')
    elif extendName[1] == None:
        print('Filename is None! Please check source file name.')
        sys.exit()
    else:
        print('Invalid extend name: %s' % extendName[1])
        sys.exit()

    try:
        newname = extendName[0] + fileDestFormat
        shutil.copyfile(fileSourceRoad,newname)
    except Error as err:
        print('Copy Failed!')
    finally:
        print('Copy Success!')

    return newname
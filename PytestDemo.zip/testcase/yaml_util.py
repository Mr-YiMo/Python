import yaml

class YamlUtil:
    #传入yaml文件
    def __init__(self,yaml_file):
        self.yaml_file = yaml_file
    #读取yaml
    def read_yaml(self):
        #打开yaml文件
        with open(self.yaml_file,'r',encoding='utf-8') as filehandle:
            value = yaml.load(filehandle.read(),Loader = yaml.FullLoader) #反序列化 yaml-->dict
            print(value,type(value))

if __name__ == '__main__':
    YamlUtil('test_api.yaml').read_yaml()

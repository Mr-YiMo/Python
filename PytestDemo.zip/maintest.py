import pytest
import os

#执行本文件中的所有测试类，一个main会执行所有的py文件
if __name__ == '__main__':
    #基于pytest.ini运行
    pytest.main(['--alluredir=./report/temp_jsonreport'])
    os.system('allure generate ./report/temp_jsonreport -o ./report/html --clean')

import pytest

@pytest.fixture(scope="function",params=["apple",'pear'],ids=['APPLE','PEAR'])
def test_fixture(request):
    print("\nfixture:这是前后置的方法，可以实现部分或局部的前置动作")
    yield request.param
    print("\nfixture:这是前后置的方法，可以实现部分或局部的后置动作")

@pytest.fixture(scope="function",params=["apple2",'pear2'],ids=['APPLE2','PEAR2'])
def test_fixture2(request):
    print("\nfixture2:这是前后置的方法，可以实现部分或局部的前置动作")
    yield request.param
    print("\nfixture2:这是前后置的方法，可以实现部分或局部的后置动作")